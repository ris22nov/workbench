from flask import Flask, jsonify
from flask_sqlalchemy import SQLAlchemy
import datetime

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:12345@localhost/amc-management'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class Base(db.Model):
    __abstract__ = True

    created_on = db.Column(db.DateTime, default=db.func.now())
    updated_on = db.Column(db.DateTime, default=db.func.now(), onupdate=db.func.now())


class Product(Base):
    __tablename__ = 'product_details'
    product_id = db.Column(db.Integer, primary_key = True)
    product_serial_no= db.Column(db.Text())
    product_name = db.Column(db.Text())
    product_specification = db.Column(db.Text())
    product_cost = db.Column(db.Float())
    purchase_order_no = db.Column(db.Text())
    delivery_date = db.Column(db.Text())
    warranty_period = db.Column(db.Integer())
    group_id = db.Column(db.Integer())
    

    def __init__(self, params):
        self.product_serial_no = params['product_serial_no']
        self.product_name = params['product_name']
        self.product_specification = params['product_specification']
        self.product_cost = params['product_cost']
        self.purchase_order_no = params['purchase_order_no']
        self.delivery_date = params['delivery_date']
        self.warranty_period = params['warranty_period']
        self.group_id = params['group_id']


class Vendor(Base):
    __tablename__ = 'vendor_details'
    vendor_id = db.Column(db.Integer, primary_key = True)
    company_name = db.Column(db.Text())
    company_address = db.Column(db.Text())
    company_phone = db.Column(db.BigInteger)
    company_email = db.Column(db.Text())
    contact_person = db.Column(db.Text())
    contact_person_mobile = db.Column(db.BigInteger)

    def __init__(self, params):
        self.company_name = params['company_name']
        self.company_address = params['company_address']
        self.company_phone = params['company_phone']
        self.company_email = params['company_email']
        self.contact_person = params['contact_person']
        self.contact_person_mobile = params['contact_person_mobile']


class ProductGroup(Base):
    __tablename__ = 'product_group'
    group_id = db.Column(db.Integer, primary_key = True)
    group_name= db.Column(db.Text())
    group_type = db.Column(db.Text())

    def __init__(self, params):
        self.group_name = params['group_name']
        self.group_type = params['group_type']

class ProductAmcDetails(Base):
    __tablename__ = 'product_amc_details'
    product_id = db.Column(db.Integer, primary_key=True)
    order_no = db.Column(db.Text(),primary_key=True)
    amc_period = db.Column(db.Integer)

    def __init__(self, params):
        self.product_id = params['product_id']
        self.order_no = params['order_no']
        self.amc_period = params['amc_period']

class PoDetails(Base):
    __tablename__ = 'po_details'
    order_no = db.Column(db.Text(), primary_key = True)
    order_date= db.Column(db.Text())
    order_amount = db.Column(db.Float())
    vendor_id = db.Column(db.Integer())
    
    def __init__(self, params):
        self.order_no = params['order_no']
        self.order_date = params['order_date']
        self.order_amount = params['order_amount']
        self.vendor_id = params['vendor_id']


class AmcDetails(Base):
    __tablename__ = 'amc_detals'
    order_no = db.Column(db.Text(), primary_key = True)
    order_date= db.Column(db.Text())
    order_amount = db.Column(db.Float())
    vendor_id = db.Column(db.Integer())

    def __init__(self, params):
        self.order_no = params['order_no']
        self.order_date = params['order_date']
        self.order_amount = params['order_amount']
        self.vendor_id = params['vendor_id']





if __name__ == '__main__':
    db.create_all()