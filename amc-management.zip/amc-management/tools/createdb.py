from flask import Flask, jsonify
from flask_sqlalchemy import SQLAlchemy
import datetime

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:12345@localhost/amc-management'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class Base(db.Model):
    __abstract__ = True

    created_on = db.Column(db.DateTime, default=db.func.now())
    updated_on = db.Column(db.DateTime, default=db.func.now(), onupdate=db.func.now())

class Vendor(Base):
    __tablename__ = 'vendor_details'
    vendor_id = db.Column(db.Integer, primary_key = True)
    comapany_name = db.Column(db.Text())
    company_address = db.Column(db.Text())
    company_phone = db.Column(db.BigInteger)
    company_email = db.Column(db.Text())
    contact_person = db.Column(db.Text())
    contact_person_mobile = db.Column(db.BigInteger)

    def __init__(self, comapany_name,company_address,company_phone,company_email,contact_person,contact_person_mobile):
        self.comapany_name = comapany_name
        self.company_address = company_address
        self.company_phone = company_phone
        self.company_email = company_email
        self.contact_person = contact_person
        self.contact_person_mobile = contact_person_mobile

class Product(Base):
    __tablename__ = 'product_details'
    product_id = db.Column(db.Integer, primary_key = True)
    product_serial_no= db.Column(db.Text())
    product_name = db.Column(db.Text())
    product_specification = db.Column(db.Text())
    product_cost = db.Column(db.Float())
    purchase_order_no = db.Column(db.Text())
    delivery_date = db.Column(db.Text())
    warranty_period = db.Column(db.Integer())
    group_id = db.Column(db.Integer())

    def __init__(self, product_serial_no,product_name,product_specification,product_cost,purhcase_order_no,delivery_date,warranty_period,group_id,):
        self.product_serial_no = product_serial_no
        self.product_name = product_name
        self.product_specification = product_specification
        self.product_cost = product_cost
        self.purchase_order_no = purhcase_order_no
        self.delivery_date = delivery_date
        self.warranty_period = warranty_period
        self.group_id = group_id


if __name__ == '__main__':
    db.create_all()