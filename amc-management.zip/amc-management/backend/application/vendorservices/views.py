from flask import Blueprint

bp = Blueprint('vendorservices', __name__)

@bp.route("/list", methods=['GET'])
def list(params):
    pass

@bp.route("/add", methods=['POST'])
def add(params):
    pass


@bp.route("/edit", methods=['POST'])
def edit(params):
    pass
