add = {
    "product_serial_no": {
        "type": "Text(0, 24)",
        "must": True
    },
    "product_name": {
        "type": "Text(0, 24)",
        "must": True      
    },
    "product_specification": {
        "type": "Text(0, 24)",
        "must": True
    },
    "product_cost": {
        "type": "Float(0,9999999)",
        "must": True
    },
    "purchase_order_no": {
        "type": "Text(0, 24)",
        "must": True
    },
    "delivery_date": {
        "type": "Text(0, 24)",
        "must": False
    },
     "warranty_period": {
        "type": "Int()",
        "must": True
    },
    "group_id": {
        "type": "Int()",
        "must": True
    }
}

# edit params
edit = {
    "product_id" : {
        "type" : "Int(min=0)",
        "must": True
    }
}
edit.update(add)

##delete
delete = {
    "product_id" : {
        "type" : "Int(min=0)",
        "must": True
    }
}

##select
select = {
}

## list
list = {
}

## Product Group
productgroup={
}
