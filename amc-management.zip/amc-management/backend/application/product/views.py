from flask import Blueprint
from base import io, validate, ok, err
from application.product.model import Product,ProductGroup,db

bp = Blueprint('product', __name__)

@bp.route("/list", methods=['GET'])
@io
@validate
def list(params):
    result = Product.query.all()
    items = []
    for row in result:
        items.append({"product_id": row.product_id, "product_serial_no": row.product_serial_no, "product_name": row.product_name, 
        "product_specification": row.product_specification, "product_cost": row.product_cost, "purchase_order_no": row.purchase_order_no,
        "delivery_date": row.delivery_date,"warranty_period":row.warranty_period,"group_id":row.group_id})
    return items

@bp.route("/select", methods=['GET'])
@io
@validate
def select(params):
    product_id = params['product_id']
    product = Product.query.filter(Product.product_id == product_id).one_or_none()
    item = []
    if product is not None:
        item.append({"product_id": product.product_id, "product_serial_no": product.product_serial_no, "product_name": product.product_name, 
        "product_specifiction": product.product_specification, "product_cost": product.product_cost, "purchase_order_no": product.purchase_order_no,
        "delivery_date": product.delivery_date,"warranty_period":product.warranty_period,"group_id":product.group_id})
        return item
    else:
        return err(f"No Product Found for Id: {product_id}")
        
@bp.route("/add", methods=['POST'])
@io
@validate
def add(params):
    product = Product(params)
    db.session.add(product)
    db.session.commit()
    return ok({"product_id": product.product_id}) if isinstance(product.product_id, int) else err("unable to save")

@bp.route("/edit", methods=['PUT'])
@io
@validate
def edit(params):
    product_id = params['product_id']
    update = Product.query.filter(Product.product_id==product_id).one_or_none()
    product = Product(params)
    if update is not None:
        product.product_id = update.product_id
        db.session.merge(product)
        db.session.commit()
        return ok({"product_id": update.product_id}) if isinstance(update.product_id, int) else err("unable to save")
    else:
        return err(f"No Product Found for Id: {product_id}")


@bp.route("/delete", methods=['DELETE'])
@io
@validate
def delete(params):
    product_id = params['product_id']
    delete = Product.query.filter(Product.product_id==product_id).one_or_none()
    if delete is not None:
        db.session.delete(delete)
        db.session.commit()
        return ok({"product_id": delete.product_id}) if isinstance(delete.product_id, int) else err("unable to delete")
    else:
        return err(f"No Product Found for Id: {product_id}")


@bp.route("/group", methods=['GET'])
@io
@validate
def productgroup(params):
    result = ProductGroup.query.all()
    items = []
    for row in result:
        items.append({"group_id": row.group_id, "group_name": row.group_name, "group_type": row.group_type})
    return items