from flask import Blueprint
from base import io, validate, ok, err
from application.product.model import Product,db

bp = Blueprint('product', __name__)

@bp.route("/list", methods=['GET'])
@io
@validate
def list(params):
    result = Product.query.all()
    items = []
    for row in result:
        items.append({"product_id": row.product_id, "product_serial_no": row.product_serial_no, "product_name": row.product_name, 
        "product_specifiction": row.product_specification, "product_cost": row.product_cost, "purchase_order_no": row.purchase_order_no,
        "delivery_date": row.delivery_date,"warranty_period":row.warranty_period,"group_id":row.group_id})
    return items

@bp.route("/add", methods=['POST'])
@io
@validate
def add(params):
    product = Product(params)
    db.session.add(product)
    db.session.commit()
    return ok({"product_id": product.product_id}) if isinstance(product.product_id, int) else err("unable to save")