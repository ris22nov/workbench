from database import db, Base

class Product(Base):
    __tablename__ = 'product_details'
    product_id = db.Column(db.Integer, primary_key = True)
    product_serial_no= db.Column(db.Text())
    product_name = db.Column(db.Text())
    product_specification = db.Column(db.Text())
    product_cost = db.Column(db.Float())
    purchase_order_no = db.Column(db.Text())
    delivery_date = db.Column(db.Text())
    warranty_period = db.Column(db.Integer())
    group_id = db.Column(db.Integer())

    def __init__(self, params):
        self.product_serial_no = params['product_serial_no']
        self.product_name = params['product_name']
        self.product_specification = params['product_specification']
        self.product_cost = params['product_cost']
        self.purchase_order_no = params['purchase_order_no']
        self.delivery_date = params['delivery_date']
        self.warranty_period = params['warranty_period']
        self.group_id = params['group_id']
