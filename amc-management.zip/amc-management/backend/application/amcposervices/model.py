from flask import Blueprint

bp = Blueprint(__name__, __name__)