from flask import Blueprint
from base import io,validate

bp = Blueprint('amcpo', __name__)

@bp.route("/list", methods=['GET'])
@io
@validate
def list(params):
    return params

@bp.route("/select/<id>", methods=['GET'])
@io
@validate
def select(params):
    pass

@bp.route("/add", methods=['POST'])
def add(params):
    pass

@bp.route("/edit", methods=['POST'])
def edit(params):
    pass

@bp.route("/delete", methods=['POST'])
def delete(params):
    pass