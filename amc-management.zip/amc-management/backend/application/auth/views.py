from flask import Blueprint

bp = Blueprint('auth', __name__)