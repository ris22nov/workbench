amcadd = {
    "order_no": {
        "type": "Text(0, 24)",
        "must": True,
        "filter": ('ucwords')
    },
    "order_date": {
        "type": "Text(0, 24)",
        "must": False
    },
    "order_amount": {
       "type": "Float(0,9999999)",
        "must": True
    },
    "vendor_id": {
        "type": "Int()",
        "must": True
    }
}

poadd = {
    "order_no": {
        "type": "Text(0, 24)",
        "must": True,
        "filter": ('ucwords')
    },
    "order_date": {
        "type": "Text(0, 24)",
        "must": False
    },
    "order_amount": {
       "type": "Float(0,9999999)",
        "must": True
    },
    "vendor_id": {
        "type": "Int()",
        "must": True
    }
}


# edit params
amcedit = {
    "order_no": {
        "type": "Text(0, 24)",
        "must": True,
        "filter": ('ucwords')}
}
amcedit.update(amcadd)

poedit = {
    "order_no": {
        "type": "Text(0, 24)",
        "must": True,
        "filter": ('ucwords')}
}
poedit.update(poadd)

## list
amclist = {
}

polist = {
}

## Delete
amcdelete = {
   "order_no": {
        "type": "Text(0, 24)",
        "must": True,
        "filter": ('ucwords')
    }
}

podelete = {
   "order_no": {
        "type": "Text(0, 24)",
        "must": True,
        "filter": ('ucwords')
    }
}