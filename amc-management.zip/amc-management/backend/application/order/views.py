from flask import Blueprint,request
from base import io, validate, ok, err
from application.order.model import PoDetails,AmcDetails,db

bp = Blueprint('order', __name__)

@bp.route("/amc/list", methods=['GET'])
@io
@validate
def amclist(params):
    result = AmcDetails.query.all()
    items = []
    for row in result:
        items.append({"order_no": row.order_no, "order_date": row.order_date, "order_amount": row.order_amount, 
        "vendor_id": row.vendor_id})
    return items


@bp.route("/po/list", methods=['GET'])
@io
@validate
def polist(params):
    result = PoDetails.query.all()
    items = []
    for row in result:
        items.append({"order_no": row.order_no, "order_date": row.order_date, "order_amount": row.order_amount, 
        "vendor_id": row.vendor_id})
    return items


@bp.route("/amc/add", methods=['POST'])
@io
@validate
def amcadd(params):
    amc = AmcDetails(params)
    db.session.add(amc)
    db.session.commit()
    return ok({"amc_no": amc.order_no}) if isinstance(amc.order_no, str) else err("unable to save")


@bp.route("/po/add", methods=['POST'])
@io
@validate
def poadd(params):
    po = PoDetails(params)
    db.session.add(po)
    db.session.commit()
    return ok({"amc_no": po.order_no}) if isinstance(po.order_no, str) else err("unable to save")


@bp.route("/amc/edit", methods=['PUT'])
@io
@validate
def amcedit(params):
    order_no = params['order_no']
    update = AmcDetails.query.filter(AmcDetails.order_no==order_no).one_or_none()
    product = AmcDetails(params)
    if update is not None:
        product.order_no = update.order_no
        db.session.merge(product)
        db.session.commit()
        return ok({"order_no": update.order_no}) if isinstance(update.order_no, str) else err("unable to save")
    else:
        return err(f"No Product Found for Id: {order_no}")


@bp.route("/po/edit", methods=['PUT'])
@io
@validate
def poedit(params):
    order_no = params['order_no']
    update = PoDetails.query.filter(PoDetails.order_no==order_no).one_or_none()
    product = PoDetails(params)
    if update is not None:
        product.order_no = update.order_no
        db.session.merge(product)
        db.session.commit()
        return ok({"order_no": update.order_no}) if isinstance(update.order_no, str) else err("unable to save")
    else:
        return err(f"No Product Found for Id: {order_no}")



@bp.route("/amc/delete", methods=['DELETE'])
@io
@validate
def amcdelete(params):
    order_no = params['order_no']
    delete = AmcDetails.query.filter(AmcDetails.order_no==order_no).one_or_none()
    if delete is not None:
        db.session.delete(delete)
        db.session.commit()
        return ok({"order_no": delete.order_no}) if isinstance(delete.order_no, str) else err("unable to delete")
    else:
        return err(f"No Product Found for Id: {order_no}")

@bp.route("/po/delete", methods=['DELETE'])
@io
@validate
def podelete(params):
    order_no = params['order_no']
    delete = PoDetails.query.filter(PoDetails.order_no==order_no).one_or_none()
    if delete is not None:
        db.session.delete(delete)
        db.session.commit()
        return ok({"order_no": delete.order_no}) if isinstance(delete.order_no, str) else err("unable to delete")
    else:
        return err(f"No Product Found for Id: {order_no}")