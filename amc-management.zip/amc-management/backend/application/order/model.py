from init import db, Base

class PoDetails(Base):
    __tablename__ = 'po_details'
    order_no = db.Column(db.Text(), primary_key = True)
    order_date= db.Column(db.Text())
    order_amount = db.Column(db.Float())
    vendor_id = db.Column(db.Integer())
    
    def __init__(self, params):
        self.order_no = params['order_no']
        self.order_date = params['order_date']
        self.order_amount = params['order_amount']
        self.vendor_id = params['vendor_id']


class AmcDetails(Base):
    __tablename__ = 'amc_detals'
    order_no = db.Column(db.Text(), primary_key = True)
    order_date= db.Column(db.Text())
    order_amount = db.Column(db.Float())
    vendor_id = db.Column(db.Integer())

    def __init__(self, params):
        self.order_no = params['order_no']
        self.order_date = params['order_date']
        self.order_amount = params['order_amount']
        self.vendor_id = params['vendor_id']


