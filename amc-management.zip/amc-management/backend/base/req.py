class Req:

    def __init__(self, request):
        self.request = request

    def data(self):
        method = self.request.method
        mimetype = self.request.mimetype
        if method == 'GET':
            return self.get()
        elif mimetype == 'application/x-www-form-urlencoded':
            return self.x_www_form_url_encoded()
        elif mimetype == 'multipart/form-data':
            return self.multipart_form_data()
        elif mimetype == 'application/json':
            return self.json()

    def get(self):
        return self.request.args.to_dict()

    def x_www_form_url_encoded(self):
        keys = self.request.form.keys()
        params = {}
        for key in keys:
            params[key] = self.request.form[key]
        return params

    def multipart_form_data(self):
        keys = self.request.form.keys()
        params = {}
        for key in keys:
            params[key] = self.request.form[key]
        return params

    def json(self):
        return self.request.get_json()

