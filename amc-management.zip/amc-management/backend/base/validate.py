from base.datatype import *


class Validate:
    def __init__(self, defns, params):
        self.defns = defns
        self.params = params
        self.valid_bit = True
        self.report = {}

    def verify(self):
        for field in self.defns:
            valid_bit, msg = self.verify_per_field(field, self.defns[field])
            self.report[field] = {"Valid": valid_bit, "Msg": msg}
            self.valid_bit = self.valid_bit and valid_bit
        return self.valid_bit, self.report

    def verify_per_field(self, field, defn):
        msg_f = ""
        valid_bit_f = True
        seed = self.params.get(field)

        # MUST
        if defn.get('must'):
            valid_bit, msg = Must.verify(seed)
            valid_bit_f = valid_bit_f and valid_bit
            msg_f += " > " + msg
            if not valid_bit:
                return valid_bit_f, msg_f

        # DEFAULT
        if defn.get('default'):
            is_default_set, self.params[field] = Default.verify(seed, defn['default'])
            seed = self.params[field]
            if is_default_set: msg_f += " > Default value set OK"

        # TYPE
        cls = eval(defn['type'])
        valid_bit, msg = cls.verify(seed)
        valid_bit_f = valid_bit_f and valid_bit
        msg_f += " > "+ msg


        # FILTER
        if defn.get('filter'):
            valid_bit, msg = Filter(defn['filter']).apply(seed)
            valid_bit_f = valid_bit_f and valid_bit
            msg_f += " > " + msg

        return valid_bit_f, msg_f