import psycopg2
import traceback
from flask_sqlalchemy import SQLAlchemy
from etc.config import Config
from flask import Flask

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:friends@localhost:5432/mydb'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class BaseModel:
    def __init__(self):
        self.connection = psycopg2.connect(user=Config.DB_USER
                                           , password=Config.DB_PSWD
                                           , host=Config.DB_HOST
                                           , port=Config.DB_PORT
                                           , database=Config.DB_NAME)

    def cursor(self):
        return self.connection.cursor()

    def __del__(self):
        try:
            self.connection.close()
        except Exception:
            print(traceback.format_exc(Exception))
