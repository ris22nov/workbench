from flask_sqlalchemy import SQLAlchemy
from flask import Flask
from authentication.oauth2 import config_oauth
from flask_cors import CORS

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:12345@localhost/amc-management'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
CORS(app)
config_oauth(app)
db = SQLAlchemy(app)

class Base(db.Model):
    __abstract__ = True

    created_on = db.Column(db.DateTime, default=db.func.now())
    updated_on = db.Column(db.DateTime, default=db.func.now(), onupdate=db.func.now())