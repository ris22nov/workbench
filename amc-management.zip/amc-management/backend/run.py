from flask import Flask, json
from pkgutil import walk_packages
from importlib import import_module
from traceback import format_exc
from werkzeug.exceptions import HTTPException
from werkzeug.wrappers import response
from flask_sqlalchemy import SQLAlchemy
from config import Config
import application
from base import io,err
from init import app



for importer, package_name, ispkg in walk_packages(path=application.__path__):
    if ispkg:
        views = import_module('.views', application.__name__ + "." + package_name)
        app.register_blueprint(views.bp, url_prefix="/" + package_name)

@app.errorhandler(HTTPException)
@io
def handle_exception(e, params):
    """Return JSON instead of HTML for HTTP errors."""
    # start with the correct headers and status code from the error
    # response = e.get_response()
    # replace the body with JSON
    response = {
        "code": e.code,
        "name": e.name,
        "description": e.description,
    }
    return err(response), e.code

@app.errorhandler(Exception)
@io
def err_500(e, params):
    trace = format_exc()
    return err(trace), 500


if __name__ == '__main__':
    app.run(host=Config.HOST, port=Config.PORT)

