//import { createEle, SortData,helpers,productGroup } from './library.js'
import {vendorhelpers, vendor } from './library.js'


// Input Tags
const order_type_in = document.getElementById('order_type')
const order_no_in = document.getElementById('order_no')
const order_date_in = document.getElementById('order_date')
const order_amount_in = document.getElementById('order_amount')
const vendor_id_in = document.getElementById('vendor_dropdown')

// Buttons
const btn_add = document.getElementById('btn_add')
const btn_edit = document.getElementById('btn_edit')

// Table
const notfound = document.getElementById("notfound");

// Today Date
const today = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate());

btn_close.onclick = (event) => {
    $("#btn_edit").hide()
    $("#order_form form").hide(1000);
    $("#btn_add").hide();
    $("#btn_close").hide();
    $("#add").show(1000);
}


$(document).ready(function(){
    var vendor_details = vendor.getVendor();
    vendorhelpers.buildDropdown(vendor_details,$('#vendor_dropdown'),'Select Vendor');
    $("#order_date").datepicker({
        showRightIcon: false,
        maxDate: today,
        header:true,
        format: "dd-mm-yyyy",
        changeMonth: true,
        changeYear: true
    });
});

$(document).ready(function () {
    $("#add").click(function(){
        order_type_in.value = "",
        order_no_in.value = "",
        order_date_in.value = "",
        order_amount_in.value = "",
        vendor_id_in.value = "",
        $("#add").css("display","none");
        $("#btn_edit").css("display","none");
        $("#order_form form").show(1000);
        $("#btn_add").show();
        $("#btn_close").show();
      });
});

// Add Record to Database
btn_add.onclick = (event) => {
    let order_type = order_type_in.value;
    let order_data = {
        order_no : order_no_in.value,
        order_date : order_date_in.value,
        order_amount : order_amount_in.value,
        vendor_id : vendor_id_in.value 
    }
    $.ajax({
        url: 'http://127.0.0.1:5000/order/'+order_type+'/add',
        data: order_data,
        type: 'POST',
        success: function(response){
            $.alert({
                title: 'Information',
                content: 'New Order Added Succesfully',
            });
        },
        error: function(error){
            console.log(error);
        }
    });

    order_type_in.value = "",
    order_no_in.value = "",
    order_date_in.value = "",
    order_amount_in.value = "",
    vendor_id_in.value = ""
}
    

// Fetch Data and Create Table
$(document).ready(function () {
    $.ajax({
        url: 'http://127.0.0.1:5000/order/amc/list',
        type: 'get',
        dataType: 'json',
        success: function (response) {
            createDatatable(response,'#amctable')
        }
    });
    $.ajax({
        url: 'http://127.0.0.1:5000/order/po/list',
        type: 'get',
        dataType: 'json',
        success: function (response) {
            createDatatable(response,'#potable')
        }
    }); 
});

function createDatatable(data,tableid){
    if (data.length >0){
        var table = $(tableid).dataTable({
            bAutoWidth : false,
            data: data,
            order: [[ 0, "asc" ]],
            columns : 
            [
                { data: 'order_no' },
                { data: 'order_date' },
                { data: 'order_amount' },
                { data: 'vendor_id' ,
                    render:function(data){
                        return vendor.getVendorName(data);}},
                {data:null,
                    searchable: false,
                    sortable:false,
                    className: "dt-center view",
                    render:function(){
                        return '<i class="fas fa-eye btnview">'
                    }},
                {data: null,
                    searchable: false,
                    sortable:false,
                    className: "dt-center edit",
                    render:function(){
                        return '<i class="fas fa-edit btnedit">'
                    }},
                {data: null,
                    searchable: false,
                    sortable:false,
                    className: "dt-center delete",
                    render:function(){
                        return '<i class="fas fa-trash-alt btndelete">'
                    }
                }
            ]
        })
    }
    else {
        notfound.textContent = "No record found in the database...!";
    }
}

//View Product
$('#potable').on('click', 'td.view', function () {
    const td = $(this).closest('tr').find('td');
    const order_no = td.get(0).innerText;
    $("#product_modal_label").html("LIST OF PRODUCTS "+order_no);
    $('#product_table_div').show();
    $("#product_modal").modal('show');
    });

$('#amctable').on('click', 'td.view', function () {
    const td = $(this).closest('tr').find('td');
    const order_no = td.get(0).innerText;
    $("#product_modal_label").html("LIST OF PRODUCTS "+order_no);
    $('#product_table_div').show();
    $("#product_modal").modal('show');
    });

// Edit Purchase Order record
$('#potable').on('click', 'td.edit', function () {
    const td = $(this).closest('tr').find('td');
    order_type_in.value = "po",
    order_no_in.value = td.get(0).innerText,
    order_date_in.value = td.get(1).innerText,
    order_amount_in.value = td.get(2).innerText,
    vendor_id_in.value = td.get(3).innerText
    var currentRow = $(this).closest("tr");
    var data = $('#potable').DataTable().row(currentRow).data();
    var vendor_id = data['vendor_id'];
    $("#vendor_dropdown option[value="+vendor_id+"]").attr('selected','selected');
    $("#btn_add").hide();
    $('#add').hide();
    $("#order_form form").show(1000);
    $("#btn_edit").show();
    $("#btn_close").show();
    btn_edit.onclick = (event) => {
        let order_data = {
            order_no : order_no_in.value,
            order_date : order_date_in.value,
            order_amount : order_amount_in.value,
            vendor_id : vendor_id_in.value 
        }
        $.ajax({
            url: 'http://127.0.0.1:5000/order/po/edit',
            data: order_data,
            type: 'PUT',
            success: function(response){
                $.alert({
                    title: 'Information',
                    content: 'Purchase Order Updated Succesfully',
                });
            },
            error: function(error){
                console.log(error);
            }
        });
    
        order_type_in.value = "",
        order_no_in.value = "",
        order_date_in.value = "",
        order_amount_in.value = "",
        vendor_id_in.value = ""
    }
    });

// Edit AMC Order record
$('#amctable').on('click', 'td.edit', function () {
    const td = $(this).closest('tr').find('td');
    order_type_in.value = "amc",
    order_no_in.value = td.get(0).innerText,
    order_date_in.value = td.get(1).innerText,
    order_amount_in.value = td.get(2).innerText,
    vendor_id_in.value = td.get(3).innerText
    var currentRow = $(this).closest("tr");
    var data = $('#amcTable').DataTable().row(currentRow).data();
    var vendor_id = data['vendor_id'];
    $("#vendor_dropdown option[value="+vendor_id+"]").attr('selected','selected');
    $("#btn_add").hide();
    $('#add').hide();
    $("#order_form form").show(1000);
    $("#btn_edit").show();
    $("#btn_close").show();
    btn_edit.onclick = (event) => {
        let order_data = {
            order_no : order_no_in.value,
            order_date : order_date_in.value,
            order_amount : order_amount_in.value,
            vendor_id : vendor_id_in.value 
        }
        $.ajax({
            url: 'http://127.0.0.1:5000/order/amc/edit',
            data: order_data,
            type: 'PUT',
            success: function(response){
                $.alert({
                    title: 'Information',
                    content: 'AMC Order Updated Succesfully',
                });
            },
            error: function(error){
                console.log(error);
            }
        });
    
        order_type_in.value = "",
        order_no_in.value = "",
        order_date_in.value = "",
        order_amount_in.value = "",
        vendor_id_in.value = ""
    }
    });

// Delete Purchase Order record
$('#potable').on('click', 'td.delete', function () {
    const td = $(this).closest('tr').find('td');
    const order_no = td.get(0).innerText;
    $.confirm({
        title: 'Delete',
        content: 'Do you Want to Delete Purchase Order with Order No <b>'+order_no+'</b> ?',
        buttons: {
            confirm: function () {
                let order_data = {
                    order_no : order_no,
                }
                $.ajax({
                    url: 'http://127.0.0.1:5000/order/po/delete',
                    data: order_data,
                    type: 'DELETE',
                    success: function(response){
                        $.alert({
                            title: 'Information',
                            content: 'Purchase Order Deleted Succesfully',
                        });
                    },
                    error: function(error){
                        console.log(error);
                    }
                });
            },
            cancel: function () {
            },
        }
    });
    
    
} );

// Delete AMC Order record
$('#amctable').on('click', 'td.delete', function () {
    const td = $(this).closest('tr').find('td');
    const order_no = td.get(0).innerText;
    $.confirm({
        title: 'Delete',
        content: 'Do you Want to Delete AMC Order with Order No <b>'+order_no+'</b> ?',
        buttons: {
            confirm: function () {
                let order_data = {
                    order_no : order_no,
                }
                $.ajax({
                    url: 'http://127.0.0.1:5000/order/amc/delete',
                    data: order_data,
                    type: 'DELETE',
                    success: function(response){
                        $.alert({
                            title: 'Information',
                            content: 'AMC Order Deleted Succesfully',
                        });
                    },
                    error: function(error){
                        console.log(error);
                    }
                });
            },
            cancel: function () {
            },
        }
    });
    
    
} );


/*jQuery.extend({
    getValues: function(url) {
        var result = null;
        $.ajax({
            url: url,
            type: 'get',
            dataType: 'json',
            async: false,
            success: function(data) {
                result = data;
            }
        });
       return result;
    }
});*/