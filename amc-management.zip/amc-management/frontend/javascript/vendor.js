//import { createEle, SortData,helpers,productGroup } from './library.js'


// Input Tags
const company_name_in = document.getElementById('company_name')
const company_address_in = document.getElementById('company_address')
const company_phone_no_in = document.getElementById('company_phone_no')
const company_email_in = document.getElementById('company_email')
const contact_person_name_in = document.getElementById('contact_person_name')
const contact_person_mobile_in= document.getElementById('contact_person_mobile')

// Buttons
const btn_add = document.getElementById('btn_add')
const btn_edit = document.getElementById('btn_edit')

// Table
const notfound = document.getElementById("notfound");

// Today Date
const today = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate());

btn_close.onclick = (event) => {
    $("#btn_edit").hide()
    $("#vendor_form form").hide(1000);
    $("#btn_add").hide();
    $("#btn_close").hide();
    $("#add").show(1000);
}

$(document).ready(function () {
    $("#add").click(function(){
        company_name_in.value = "",
        company_address_in.value = "",
        company_phone_no_in.value = "",
        company_email_in.value = "",
        contact_person_name_in.value = "",
        contact_person_mobile_in.value = "",
        $("#add").css("display","none");
        $("#btn_edit").css("display","none");
        $(".d-flex form").show(1000);
        $("#btn_add").show();
        $("#btn_close").show();
      });
});

// Add Record to Database
btn_add.onclick = (event) => {
    let vendor_data = {
        company_name : company_name_in.value,
        company_address: company_address_in.value,
        company_phone : company_phone_no_in.value,
        company_email : company_email_in.value,
        contact_person : contact_person_name_in.value,
        contact_person_mobile : contact_person_mobile_in.value,
    }
    console.log(vendor_data)
    $.ajax({
        url: 'http://127.0.0.1:5000/vendor/add',
        data: vendor_data,
        type: 'POST',
        success: function(response){
            $.alert({
                title: 'Information',
                content: 'New Vendor Added Succesfully',
            });
        },
        error: function(error){
            console.log(error);
        }
    });

    company_name_in.value = "",
    company_address_in.value = "",
    company_phone_no_in.value = "",
    company_email_in.value = "",
    contact_person_name_in.value = "",
    contact_person_mobile_in.value = ""
}

// Fetch Data and Create Table
$(document).ready(function () {
    $.ajax({
        url: 'http://127.0.0.1:5000/vendor/list',
        type: 'get',
        dataType: 'json',
        success: function (response) {
            createDatatable(response);
        }
    });
});

function createDatatable(data){
    if (data.length >0){
        var table = $('#vendorTable').dataTable({
            bAutoWidth : false,
            data: data,
            order: [[ 0, "asc" ]],
            columns : 
            [
                { data: 'vendor_id' },
                { data: 'company_name' },
                { data: 'company_address' },
                { data: 'company_phone' },
                { data: 'company_email' },
                { data: 'contact_person' },
                { data: 'contact_person_mobile' },
                {data: null,
                    searchable: false,
                    sortable:false,
                    className: "dt-center edit",
                    render:function(){
                        return '<i class="fas fa-edit btnedit">'
                    }},
                {data: null,
                    searchable: false,
                    sortable:false,
                    className: "dt-center delete",
                    render:function(){
                        return '<i class="fas fa-trash-alt btndelete">'
                    }
                }
            ]
        })
    }
    else {
        notfound.textContent = "No record found in the database...!";
    }
}

// Edit record
$('#vendorTable').on('click', 'td.edit', function () {
    const td = $(this).closest('tr').find('td');
    const vendor_id = td.get(0).innerText;
    company_name_in.value = td.get(1).innerText,
    company_address_in.value = td.get(2).innerText,
    company_phone_no_in.value = td.get(3).innerText,
    company_email_in.value = td.get(4).innerText,
    contact_person_name_in.value = td.get(5).innerText,
    contact_person_mobile_in.value = td.get(6).innerText,
    $("#btn_add").hide()
    $(".d-flex form").show(1000);
    $("#btn_edit").show();
    $('#add').hide();
    $("#btn_close").show();
    btn_edit.onclick = (event) => {
        let vendor_data = {
            vendor_id : product_id,
            company_nmae : company_name_in.value,
            company_address: company_address_in.value,
            company_phone_no : company_phone_no_in.value,
            company_email : company_email_in.value,
            contact_person_name : contact_person_name_in.value,
            contact_person_mobile :contact_person_mobile_in.value,
        }
        $.ajax({
            url: 'http://127.0.0.1:5000/vendor/edit',
            data: vendor_data,
            type: 'PUT',
            success: function(response){
                $.alert({
                    title: 'Information',
                    content: 'Vendor Updated Succesfully',
                });
            },
            error: function(error){
                console.log(error);
            }
        });
    
        company_name_in.value = "",
        company_address_in.value = "",
        company_phone_no_in.value = "",
        company_email_in.value = "",
        contact_person_name_in.value = "",
        contact_person_mobile_in.value = ""
    }
    });

// Delete a record
$('#vendorTable').on('click', 'td.delete', function () {
    const td = $(this).closest('tr').find('td');
    const vendor_id = td.get(0).innerText;
    const company_name = td.get(1).innerText;
    $.confirm({
        title: 'Delete',
        content: 'Do you Want to Delete Vendor with Name <b>'+company_name+'</b> ?',
        buttons: {
            confirm: function () {
                let vendor_data = {
                    vendor_id : vendor_id,
                }
                $.ajax({
                    url: 'http://127.0.0.1:5000/vendor/delete',
                    data: vendor_data,
                    type: 'DELETE',
                    success: function(response){
                        $.alert({
                            title: 'Information',
                            content: 'Vendor Deleted Succesfully',
                        });
                    },
                    error: function(error){
                        console.log(error);
                    }
                });
            },
            cancel: function () {
            },
        }
    });
    
    
} );


/*jQuery.extend({
    getValues: function(url) {
        var result = null;
        $.ajax({
            url: url,
            type: 'get',
            dataType: 'json',
            async: false,
            success: function(data) {
                result = data;
            }
        });
       return result;
    }
});*/