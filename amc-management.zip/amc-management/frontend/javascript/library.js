// Create Dynamic Element
export const createEle = (tagName,appendTo,func) => {
    const element = document.createElement(tagName);
    if(appendTo)
        appendTo.appendChild(element);
    if(func) 
        func(element);
}

export const SortData = (data) => {
    let obj = {};
    obj = {
        product_id: data.product_id,
        product_serial_no: data.product_serial_no,
        purchase_order_no:data.purchase_order_no,
        product_name: data.product_name, 
        product_specifiction: data.product_specification,
        product_cost: data.product_cost,
        purchase_order_no: data.purchase_order_no,        
        delivery_date: data.delivery_date,
        warranty_period: data.warranty_period,
        group_id: data.group_id
    };
    return obj;
  }

export const helpers =
  {
      buildDropdown: function(result, dropdown, emptyMessage)
      {
          // Remove current options
          dropdown.html('');
          // Add the empty option with the empty message
          dropdown.append('<option value="" disabled selected hidden>' + emptyMessage + '</option>');
  
          // Check result isnt empty
          if(result != '')
          {
              // Loop through each of the results and append the option to the dropdown
              $.each(result, function(k, v) {
                  dropdown.append('<option value="' + v.group_id + '">' + v.group_name + '</option>');
              });
          }
      }
}

export const productGroup = (function(){
    var product_group;

    $.ajax({
        url: 'http://127.0.0.1:5000/product/group',
        type: 'get',
        dataType: 'json',
        async: false,
        success: function (response) {  
            product_group = response
        }
    });
    return {
        getProductGroup : function()
        {
            if (product_group) return product_group;
            // else show some error that it isn't loaded yet;
        },
        getProductName : function(group_id)
        {
            let product_name;
            $.each(product_group,function(i,v){
                if (v.group_id == group_id){
                    product_name = v.group_name;
                    return false;
                }
                else{
                    product_name = 'Product Type Not Available';
                }  
            });
            return product_name
        }};
})();

export const pohelpers =
  {
      buildDropdown: function(result, dropdown, emptyMessage)
      {
          // Remove current options
          dropdown.html('');
          // Add the empty option with the empty message
          dropdown.append('<option value="" disabled selected hidden>' + emptyMessage + '</option>');
  
          // Check result isnt empty
          if(result != '')
          {
              // Loop through each of the results and append the option to the dropdown
              $.each(result, function(k, v) {
                  dropdown.append('<option value="' + v.order_no + '">' + v.order_no + '</option>');
              });
          }
      }
}

export const purchaseOrder = (function(){
    var purchase_order;

    $.ajax({
        url: 'http://127.0.0.1:5000/order/po/list',
        type: 'get',
        dataType: 'json',
        async: false,
        success: function (response) {  
            purchase_order = response
        }
    });
    return {
        getPurchaseOrder : function()
        {
            if (purchase_order) return purchase_order;
            // else show some error that it isn't loaded yet;
        },
        getPurchaseOrderName : function(order_no)
        {
            let product_name;
            $.each(purchase_order,function(i,v){
                if (v.order_no == order_no){
                    product_name = v.group_name;
                    return false;
                }
                else{
                    product_name = 'Product Type Not Available';
                }  
            });
            return product_name
        }};
})();

export const amchelpers =
  {
      buildDropdown: function(result, dropdown, emptyMessage)
      {
          // Remove current options
          dropdown.html('');
          // Add the empty option with the empty message
          dropdown.append('<option value="" disabled selected hidden>' + emptyMessage + '</option>');
  
          // Check result isnt empty
          if(result != '')
          {
              // Loop through each of the results and append the option to the dropdown
              $.each(result, function(k, v) {
                  dropdown.append('<option value="' + v.order_no + '">' + v.order_no + '</option>');
              });
          }
      }
}

export const amcOrder = (function(){
    var amc_order;

    $.ajax({
        url: 'http://127.0.0.1:5000/order/amc/list',
        type: 'get',
        dataType: 'json',
        async: false,
        success: function (response) {  
            amc_order = response
        }
    });
    return {
        getAmcOrder : function()
        {
            if (amc_order) return amc_order;
            // else show some error that it isn't loaded yet;
        },
        getPurchaseOrderName : function(order_no)
        {
            let product_name;
            $.each(purchase_order,function(i,v){
                if (v.order_no == order_no){
                    product_name = v.group_name;
                    return false;
                }
                else{
                    product_name = 'Product Type Not Available';
                }  
            });
            return product_name
        }};
})();

export const vendorhelpers =
  {
      buildDropdown: function(result, dropdown, emptyMessage)
      {
          // Remove current options
          console.log(result)
          dropdown.html('');
          // Add the empty option with the empty message
          dropdown.append('<option value="" disabled selected hidden>' + emptyMessage + '</option>');
  
          // Check result isnt empty
          if(result != '')
          {
              // Loop through each of the results and append the option to the dropdown
              $.each(result, function(k, v) {
                  dropdown.append('<option value="' + v.vendor_id + '">' + v.company_name + '</option>');
              });
          }
      }
}

export const vendor = (function(){
    var vendor;

    $.ajax({
        url: 'http://127.0.0.1:5000/vendor/list',
        type: 'get',
        dataType: 'json',
        async: false,
        success: function (response) {  
            vendor = response
        }
    });
    return {
        getVendor : function()
        {
            if (vendor) return vendor;
            // else show some error that it isn't loaded yet;
        },
        getVendorName : function(vendor_id)
        {
            let vendor_name;
            $.each(vendor,function(i,v){
                if (v.vendor_id == vendor_id){
                    vendor_name = v.company_name;
                    return false;
                }
                else{
                    vendor_name = 'Vendor Details Not Available';
                }  
            });
            return vendor_name
        }};
})();