import { createEle, SortData,helpers,productGroup, purchaseOrder, pohelpers,amchelpers,amcOrder } from './library.js'


// Input Tags
const product_serial_no_in = document.getElementById('product_serial_no')
const purchase_order_no_in = document.getElementById('purchase_order_no')
const product_name_in = document.getElementById('product_name')
const product_specification_in = document.getElementById('product_specification')
const product_cost_in = document.getElementById('product_cost')
const delivery_date_in = document.getElementById('delivery_date')
const warranty_period_in = document.getElementById('warranty_period')
const group_id_in = document.getElementById('group_id')

// Buttons
const btn_add = document.getElementById('btn_add')
const btn_edit = document.getElementById('btn_edit')
const btn_close = document.getElementById('btn_close')
const modal_add = document.getElementById('modal_add')
const modal_save = document.getElementById('modal_save')

// Modal Input Tags
const product_id_in = document.getElementById('#amc_modal_hidden_label')
const amc_order_in = document.getElementById('#amc_order_no')
const amc_amount_in = document.getElementById('#amc_amount')
const amc_period_in = document.getElementById('#amc_period')

// Table
const notfound = document.getElementById("notfound");

// Today Date
const today = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate());

$(document).ready(function(){
    var product_group = productGroup.getProductGroup();
    helpers.buildDropdown(product_group,$('#group_id'),'--Select Hardware Type--');
    var po = purchaseOrder.getPurchaseOrder();
    pohelpers.buildDropdown(po,$('#purchase_order_no'),'--Select Purchase Order--')
    var amc = amcOrder.getAmcOrder();
    amchelpers.buildDropdown(amc,$('#amc_order_no'),'--Select AMC Order--')
    $("#delivery_date").datepicker({
        showRightIcon: false,
        maxDate: today,
        header:true,
        format: "dd-mm-yyyy",
        changeMonth: true,
        changeYear: true
    });
});

$(document).ready(function () {
    $("#add").click(function(){
        product_serial_no_in.value = "",
        purchase_order_no_in.value = "",
        product_name_in.value = "",
        product_specification_in.value = "",
        product_cost_in.value = "",
        delivery_date_in.value = "",
        warranty_period_in.value = "",
        group_id_in.value = ""
        $("#add").hide()
        $("#btn_edit").hide()
        $("#product_form form").show(1000);
        $("#btn_add").show();
        $("#btn_close").show();
      });
});

modal_add.onclick = (event) => {
    $('#modal_save').show();
    $('#amc_table_div').hide();
    $('#modal_add').hide();
    $('#amc_form_div form').show(500);   
}

modal_save.onclick = (event) => {
    let product_amc_data = {
        product_id = product_id_in.value,
        amc_order = amc_order_in.value,
        amc_amount = amc_amount_in.value,
        amc_period = amc_period_in.value
    }
    $.ajax({
        url: 'http://127.0.0.1:5000/product/amc/add',
        data: product_amc_data,
        type: 'POST',
        success: function(response){
            $.alert({
                title: 'Information',
                content: 'New AMC Added Succesfully',
            });
        },
        error: function(error){
            console.log(error);
        }
    });
    product_id_in.value="",
    amc_order_in.value="",
    amc_amount_in.value="",
    amc_period_in.value=""
 
}

btn_close.onclick = (event) => {
    $("#btn_edit").hide()
    $("#product_form form").hide(1000);
    $("#btn_add").hide();
    $("#btn_close").hide();
    $("#add").show(1000);
}

// Add Record to Database
btn_add.onclick = (event) => {
    let product_data = {
        product_serial_no : product_serial_no_in.value,
        purchase_order_no: purchase_order_no_in.value,
        product_name : product_name_in.value,
        product_specification : product_specification_in.value,
        product_cost : product_cost_in.value,
        delivery_date : delivery_date_in.value,
        warranty_period : warranty_period_in.value,
        group_id : group_id_in.value
    }
    $.ajax({
        url: 'http://127.0.0.1:5000/product/add',
        data: product_data,
        type: 'POST',
        success: function(response){
            $.alert({
                title: 'Information',
                content: 'New Product Added Succesfully',
            });
        },
        error: function(error){
            console.log(error);
        }
    });

    $.ajax({
        url: 'http://127.0.0.1:5000/product/list',
        type: 'get',
        dataType: 'json',
        success: function (response) {
            createDatatable(response);
        }
    });
    

    product_serial_no_in.value = "",
    purchase_order_no_in.value = "",
    product_name_in.value = "",
    product_specification_in.value = "",
    product_cost_in.value = "",
    delivery_date_in.value = "",
    warranty_period_in.value = "",
    group_id_in.value = ""



}

// Fetch Data and Create Table
$(document).ready(function () {
    $.ajax({
        url: 'http://127.0.0.1:5000/product/list',
        type: 'get',
        dataType: 'json',
        success: function (response) {
            createDatatable(response);
        }
    });
});

function createDatatable(data){
    if (data.length >0){
        var table = $('#productTable').DataTable({
            bAutoWidth : false,
            data: data,
            order: [[ 0, "asc" ]],
            columns : 
            [
                { data: 'product_id' },
                { data: 'product_serial_no' },
                { data: 'purchase_order_no' },
                { data: 'product_name' },
                { data: 'product_specification' },
                { data: 'product_cost' },
                { data: "delivery_date"},
                { data: "warranty_period"},
                { data: "group_id",
                    render:function(data){
                        return productGroup.getProductName(data);
                    }},
                {data:null,
                    searchable: false,
                    sortable:false,
                    className: "dt-center view",
                    render:function(){
                        return '<i class="fas fa-eye btnview">'
                    }},
                {data: null,
                    searchable: false,
                    sortable:false,
                    className: "dt-center edit",
                    render:function(){
                        return '<i class="fas fa-edit btnedit">'
                    }},
                {data: null,
                    searchable: false,
                    sortable:false,
                    className: "dt-center delete",
                    render:function(){
                        return '<i class="fas fa-trash-alt btndelete">'
                    }
                }
            ]
        })
    }
    else {
        notfound.textContent = "No record found in the database...!";
    }
}

//View AMC
$('#productTable').on('click', 'td.view', function () {
    const td = $(this).closest('tr').find('td');
    const product_id = td.get(0).innerText;
    const product_sno = td.get(1).innerText;
    $("#amc_modal_label").html("AMC DETAILS "+product_sno);
    $("#amc_modal_hidden_label").html(product_id);
    $("#amc_modal_hidden_label").hide()
    $('#amc_table_div').show();
    $('#amc_form_div form').hide();
    $('#modal_save').hide();
    $('#modal_add').show();
    $("#amc_modal").modal('show');
    });



// Edit record
$('#productTable').on('click', 'td.edit', function () {
    const td = $(this).closest('tr').find('td');
    const product_id = td.get(0).innerText;
    product_serial_no_in.value = td.get(1).innerText,
    purchase_order_no_in.value = td.get(2).innerText,
    product_name_in.value = td.get(3).innerText,
    product_specification_in.value = td.get(4).innerText,
    product_cost_in.value = td.get(5).innerText,
    delivery_date_in.value = td.get(6).innerText,
    warranty_period_in.value = td.get(7).innerText
    var currentRow = $(this).closest("tr");
    var data = $('#productTable').DataTable().row(currentRow).data();
    var group_id = data['group_id'];
    $("#group_id option[value="+group_id+"]").attr('selected','selected');
    $("#btn_add").hide()
    $('#add').hide()
    $(".d-flex form").show(1000);
    $("#btn_edit").show();
    $("#btn_close").show();
    btn_edit.onclick = (event) => {
        let product_data = {
            product_id : product_id,
            product_serial_no : product_serial_no_in.value,
            purchase_order_no: purchase_order_no_in.value,
            product_name : product_name_in.value,
            product_specification : product_specification_in.value,
            product_cost : product_cost_in.value,
            delivery_date : delivery_date_in.value,
            warranty_period : warranty_period_in.value,
            group_id : group_id_in.value
        }
        $.ajax({
            url: 'http://127.0.0.1:5000/product/edit',
            data: product_data,
            type: 'PUT',
            success: function(response){
                $.alert({
                    title: 'Information',
                    content: 'Product Updated Succesfully',
                });
            },
            error: function(error){
                console.log(error);
            }
        });
    
        product_serial_no_in.value = "",
        purchase_order_no_in.value = "",
        product_name_in.value = "",
        product_specification_in.value = "",
        product_cost_in.value = "",
        delivery_date_in.value = "",
        warranty_period_in.value = "",
        group_id_in.value = ""
    }
    });

// Delete a record
$('#productTable').on('click', 'td.delete', function () {
    const td = $(this).closest('tr').find('td');
    const product_id = td.get(0).innerText;
    const product_srno = td.get(1).innerText;
    $.confirm({
        title: 'Delete',
        content: 'Do you Want to Delete Product with Serial No <b>'+product_srno+'</b> ?',
        buttons: {
            confirm: function () {
                let product_data = {
                    product_id : product_id,
                }
                $.ajax({
                    url: 'http://127.0.0.1:5000/product/delete',
                    data: product_data,
                    type: 'DELETE',
                    success: function(response){
                        $.alert({
                            title: 'Information',
                            content: 'Product Deleted Succesfully',
                        });
                    },
                    error: function(error){
                        console.log(error);
                    }
                });
            },
            cancel: function () {
            },
        }
    });
    
    
} );


/*jQuery.extend({
    getValues: function(url) {
        var result = null;
        $.ajax({
            url: url,
            type: 'get',
            dataType: 'json',
            async: false,
            success: function(data) {
                result = data;
            }
        });
       return result;
    }
});*/