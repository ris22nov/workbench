import React from "react";
import { FiSearch } from "react-icons/fi";
import { NavbarContainer,Text,InputContainer,Icon,Input } from './Header.styles'


export default Header = () => {
  return (
    <NavbarContainer>
      <Text>
        Good morning,
        <span> Kishan</span>
      </Text>
      <InputContainer>
        <Icon>
          <FiSearch />
        </Icon>
        <Input type="text" placeholder="Search for projects" />
      </InputContainer>
    </NavbarContainer>
  );
};
