import React from 'react';
import { PivotViewComponent, FieldList, CalculatedField, Inject } from '@syncfusion/ej2-react-pivotview';
import {pivotData} from './data';
import './App.css';

function App() {
 return (
    <div id="wrapper">
      <PivotViewComponent 
        height={'500'}
        width={'100%'}
        dataSourceSettings={{
          dataSource: pivotData,
          rows: [{name:"Status"}, {name: "Method"}],
          columns:[{name:"SVS",showSubTotals: false },{name: "SVS Status",showSubTotals: false }],
          values: [{name: "Count", caption: "Count"}, {name: "Amount", caption: "Amount"}],
          filters: [{name: "Quarter"}],
          calculatedFieldSettings: [{
            name: "Total",
            formula: '"Sum(Amount)"+"Sum(Sold)"' 
          }]
        }}
        showFieldList={true}
        allowCalculatedField={true}>
          <Inject services={[FieldList, CalculatedField]}></Inject>
      </PivotViewComponent>
    </div>
  );
}

export default App;
