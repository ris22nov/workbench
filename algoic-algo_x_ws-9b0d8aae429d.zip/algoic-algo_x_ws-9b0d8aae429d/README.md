# algo_x
the algo_x project

### Docker Guide

$ sudo docker build -t algo_x .


$ sudo docker run -it --rm -p 5000:5000 --mount type=bind,source="$(pwd)"/,target=/usr/src/app/ --name algo_x_container algo_x


### DB Migration

#### This command is run only once; at the begining of the project

$ python3 manage.py db init


#### Whenever there is table schema related changes execute the below commands to incorporte the changes into existing DB

$ python3 manage.py db migrate

$ python3 manage.py db upgrade

