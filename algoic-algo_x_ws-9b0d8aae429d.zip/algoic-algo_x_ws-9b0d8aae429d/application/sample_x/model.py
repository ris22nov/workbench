from base.model import db, BaseModel
# from run import db

class SampleX(db.Model):
    __tablename__ = "sample_x"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String())
    email = db.Column(db.String(), unique=True)
    gender = db.Column(db.String())
    phone = db.Column(db.String())
    age = db.Column(db.Integer)

    def __init__(self, params):
        self.name = params['name']
        self.email = params['email']
        self.gender = params['gender']
        self.phone = params['phone']
        self.age = params['age']


    def __repr__(self):
        return f"<id={self.id}, name={self.name}>"


    def add(self, params):
        pass







