add = {
    "name": {
        "type": "Text(0, 24)",
        "must": True,
        "filter": ('ucwords')
    }
    ,
    "email": {
        "type": "Email()",
        "must": True
    },
    "gender": {
        "type": "Set('male', 'female', 'other')",
        "must": True,
        "default": 'male'
    },
    "phone": {
        "type": "Mobile()",
        "must": True
    },
    "age": {
        "type": "Int(0, 150)",
        "must": True
    }
}


# edit params
edit = {
    "id" : {
        "type" : "Int(min=0)",
        "must": True
    }
}
edit.update(add)


## list
list = {
}
