from flask import Blueprint
from base import io, validate, ok, er
from application.sample_x.model import SampleX, db
bp = Blueprint(__name__, __name__)

@bp.route("/list", methods=['GET'])
@io
@validate
def list(params):
    result = SampleX.query.all()
    items = []
    for row in result:
        items.append({"id": row.id, "name": row.name, "email": row.email, "gender": row.gender, "phone": row.phone, "age": row.age})

    return items

@bp.route("/add", methods=['POST'])
@io
@validate
def add(params):
    sx = SampleX(params)
    db.session.add(sx)
    db.session.commit()
    return ok({"id": sx.id}) if isinstance(sx.id, int) else er("unable to save")


@bp.route("/edit", methods=['POST'])
@io
@validate
def edit(params):
    return {"params": params}
