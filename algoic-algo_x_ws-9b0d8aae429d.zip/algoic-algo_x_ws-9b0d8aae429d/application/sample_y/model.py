from base.model import db
class SampleY(db.Model):
    __tablename__ = "sample_y"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String())

    # def __init__(self, name):
    #     # self.id = id
    #     self.name = name

    def __repr__(self):
        return '{"id": self.id, "name": self.name}'