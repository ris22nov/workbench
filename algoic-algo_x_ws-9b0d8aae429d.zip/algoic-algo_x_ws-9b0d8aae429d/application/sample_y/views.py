from flask import Blueprint
from base import io, validate, ok, er
from application.sample_y.model import SampleY, db
import flask_sqlalchemy
bp = Blueprint(__name__, __name__)


@bp.route("/list", methods=['GET'])
@io
@validate
def list(params):
    result = SampleY.query.all()
    print(result)
    items = []
    for row in result:
        items.append({"id": row.id, "name": row.name})
    return items

@bp.route("/add", methods=['POST'])
@io
@validate
def add(params):
    sy = SampleY(name=params['name'])
    db.session.add(sy)
    db.session.commit()
    return ok({"id": sy.id}) if isinstance(sy.id, int) else er("unable to save")
