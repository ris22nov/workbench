add = {
    "name": {
        "type": "Text(0, 24)",
        "must": True,
        "filter": ('ucwords')
    }
}


# edit params
edit = {
    "id" : {
        "type" : "Int(min=0)",
        "must": True
    }
}
edit.update(add)


## list
list = {
}
