from flask import Flask, json
from pkgutil import walk_packages
from base import io, er
from importlib import import_module
from traceback import format_exc
from werkzeug.exceptions import HTTPException
import application
from flask_sqlalchemy import SQLAlchemy
from etc.config import Config
import os

# app = Flask(__name__)
# app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:friends@localhost:5432/mydb'
# app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
# db = SQLAlchemy(app)

from base.model import app

# from application.sample_x.model import *

for importer, package_name, ispkg in walk_packages(path=application.__path__):
    if ispkg:
        views = import_module('.views', application.__name__ + "." + package_name)
        # model = import_module('.model', application.__name__ + "." + package_name)
        app.register_blueprint(views.bp, url_prefix="/" + package_name)


@app.errorhandler(HTTPException)
@io
def handle_exception(e, params):
    """Return JSON instead of HTML for HTTP errors."""
    # start with the correct headers and status code from the error
    # response = e.get_response()
    # replace the body with JSON
    response = {
        "code": e.code,
        "name": e.name,
        "description": e.description,
    }
    return er(response), e.code

@app.errorhandler(Exception)
@io
def err_500(e, params):
    trace = format_exc()
    print(trace)
    return er(trace), 500


if __name__ == '__main__':
    app.run(host=Config.HOST, port=Config.PORT)