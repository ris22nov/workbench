from flask_script import Manager
from flask_migrate import Migrate, MigrateCommand
from pkgutil import walk_packages
from importlib import import_module
import application
from base.model import app, db

for importer, package_name, ispkg in walk_packages(path=application.__path__):
    if ispkg:
        model = import_module('.model', application.__name__ + "." + package_name)

migrate = Migrate(app, db)
manager = Manager(app)

manager.add_command("db", MigrateCommand)



if __name__ == "__main__":
    manager.run()