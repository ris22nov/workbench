import re
MAX_LEN=65535
MIN_INT=-9223372036854775807
MAX_INT=9223372036854775807
class Must:

    @staticmethod
    def verify(seed):
        if seed is None:
            return False, "This field is compulsory"
        else:
            return True, "Compulsory OK"


class Default:

    @staticmethod
    def verify(seed, default_value):
        if seed is None:
            return True, default_value
        else:
            return False, seed


class Filter:

    def __init__(self, filters):
        self.filters = filters

    def apply(self, seed):
        valid_bit, msg = True, "Filters OK"
        for filt in self.filters:
            try:
                if filt == 'int': seed = int(seed)
                if filt == 'float': seed = float(seed)
                if filt == 'upper': seed = str(seed).upper()
                if filt == 'lower': seed = str(seed).lower()
            except (ValueError, TypeError):
                valid_bit, msg = False, "Unable to apply filter %s" % filt
                break
        return valid_bit, msg


class RegEx:
    def __init__(self, expression):
        self.expression = expression

    def verify(self, seed):
        if (not isinstance(seed, str)) or re.match(self.expression, seed) is None:
            return False, "Must satisfy " + str(self.expression)
        else:
            return True, "OK"


class Text:
    def __init__(self, minlen=0, maxlen=MAX_LEN):
        self.expression = r'^.{'+str(minlen)+','+str(maxlen)+'}$'

    def verify(self, seed):
        return RegEx(self.expression).verify(seed)


class Alpha():
    def __init__(self, minlen=0, maxlen=MAX_LEN):
        self.expression = r'^[a-zA-Z]{' + str(minlen) + ',' + str(maxlen) + '}$'

    def verify(self, seed):
        return RegEx(self.expression).verify(seed)


class Alphanumeric:
    def __init__(self, minlen=0, maxlen=MAX_LEN):
        self.expression = r'^[a-zA-Z0-9]{' + str(minlen) + ',' + str(maxlen) + '}$'

    def verify(self, seed):
        return RegEx(self.expression).verify(seed)


class Numerictext:
    def __init__(self, minlen=0, maxlen=MAX_LEN):
        self.expression = r'^[0-9]{' + str(minlen) + ',' + str(maxlen) + '}$'

    def verify(self, seed):
        return RegEx(self.expression).verify(seed)


class Float:

    def __init__(self, min, max):
        self.max = max
        self.min = min

    def verify(self, seed):
        try:
            seed = float(seed)
            if self.min <= seed <= self.max:
                return True, "Range OK"
            else:
                return False, "Must be in range ({},{})".format(self.min, self.max)
        except (ValueError, TypeError):
            return False, "Must be an integer or float in range ({},{})".format(self.min, self.max)


class Int:
    def __init__(self, min=MIN_INT, max=MAX_INT):
        self.max = max
        self.min = min

    def verify(self, seed):
        try:
            seed = int(seed)
            if self.min <= seed <= self.max:
                return True, "Integer range OK"
            else:
                return False, "Must be in range ({},{})".format(self.min, self.max)
        except (ValueError, TypeError):
            return False, "Must be an integer in range ({},{})".format(self.min, self.max)


class Set:
    def __init__(self, *args):
        self.set = set(args)

    def verify(self, seed):
        try:
            if isinstance(list(self.set)[0], int): seed = int(seed)
            if isinstance(list(self.set)[0], float): seed = float(seed)
            if seed in self.set:
                return True, "Set membership OK"
            else:
                return False, "Must be in set " + str(self.set)
        except (ValueError, TypeError):
            return False, "Must be in set " + str(self.set)


class Bit:
    def __init__(self):
        pass

    def verify(self, seed):
        try:
            seed = int(seed)
            if seed in [0, 1]: return True, "Bit is OK"
            else: return False, "Must be a bit 0/1"
        except (ValueError, TypeError):
            return False, "Must be a bit 0/1"


class Email:
    def __init__(self):
        self.expression = r'[\w.-]+@[\w.-]+.\w+'

    def verify(self, seed):
        return RegEx(self.expression).verify(seed)



class Mobile:

    def __init__(self):
        self.expression = r'[\d]{10}'

    def verify(self, seed):
        return RegEx(self.expression).verify(seed)


if __name__ == "__main__":
    obj = Set(4, 6, 9)
