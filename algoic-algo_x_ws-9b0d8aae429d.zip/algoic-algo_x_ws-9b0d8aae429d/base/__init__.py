from flask import request, jsonify
from base.Validate import Validate
import json
from importlib import import_module
import os
from base.Validate import Validate
from functools import wraps
from base.rq import Rq

def ok(p):
    return {"ok": 1, "resp" : p}

def er(p):
    return {"ok": 0, "resp": p}

def io(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        print(request.mimetype, request.method, request.form.keys())
        # params = request.args.to_dict()
        params = Rq(request).data()
        kwargs['params'] = params

        r = f(*args, **kwargs)
        if isinstance(r, tuple):
            response_data, http_code = r
        else:
            (response_data, http_code) = (r, 200)

        return jsonify(response_data), http_code
    return wrapper


def validate(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        splitted = f.__module__.split(".")[0:-1]
        pkg_path = ".".join(splitted)
        inputs = import_module('.inputs', pkg_path)
        valid, report = Validate(getattr(inputs, f.__name__), kwargs['params']).verify()
        # kwargs['valid'] = valid
        # kwargs['report'] = report
        if valid:
            r = f(*args, **kwargs)
        else:
            r = er({"Validation_Passed": valid, "Validation_Report": report, "Params": kwargs['params']}), 500

        return r
    return wrapper
