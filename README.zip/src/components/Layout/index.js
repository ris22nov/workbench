import React from 'react';
import { Container } from './Layout.styles';
import { MainContent } from '../MainContent'
import { Header } from '../Header';
import { Footer } from '../Footer';

export const Layout = () => (
  <Container>
      <Header />
      <MainContent />
      <Footer />
  </Container>
);