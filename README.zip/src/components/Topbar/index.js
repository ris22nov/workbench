import react from "react";
import { MdNotificationsNone,MdColorLens,MdSettings } from "react-icons/md";
import { TopbarDiv,TopbarWrapper,Heading,TopLeft, Centre,TopRight, Search,TopbarIconContainer,TopAvatar,TopIconBadge, TopCentre, SearchBox } from "./Topbar.styles";
import CanaraLogo from '../../assets/images/logo.png'

const Topbar = () => {
    return (
        <TopbarDiv>
            <TopbarWrapper>
                <TopLeft>
                    <Heading>Inward Dashboard</Heading>
                </TopLeft>
                <TopRight>
                    <TopbarIconContainer>
                    </TopbarIconContainer>
                    <TopbarIconContainer>
                        <MdNotificationsNone />
                    </TopbarIconContainer>
                    <TopbarIconContainer>
                        <MdColorLens />
                    </TopbarIconContainer>
                    <TopbarIconContainer>
                        <MdSettings />
                    </TopbarIconContainer>
                    <TopAvatar src={CanaraLogo} alt=""/>
                </TopRight>
            </TopbarWrapper>
        </TopbarDiv>
    );
};

export default Topbar;