import styled from 'styled-components';

const backgroundColor = "#6100d4";
const darkThemeColor = "#162349";
const hoverEffect = `rgba(0, 0, 0, 0.56) 0px 22px 70px 4px`;
const cardShadow = `rgba(0, 0, 0, 0.1) 0px 20px 25px -5px,
    rgba(0, 0, 0, 0.04) 0px 10px 10px -5px`;

export const Card = styled.div`
  height: 100%;
  width: 15vw;
  background-color: ${props => props.inputColor};
  padding: 1rem;
  border-radius: 1rem;
  color: black;
  transition: 0.4s ease-in-out;
  box-shadow: ${cardShadow};
  &:hover {
    box-shadow: ${hoverEffect};
  }
  @media screen and (min-width: 320px) and (max-width: 1080px) {
    width: 80%;
  }
`;

export const CardContent = styled.div`
  margin: 1rem;
`;

export const Chart = styled.div`
  display: flex;
  justify-content: center;
  svg {
    height: 4rem;
    width: 4rem;
  }
`;

export const HeadingText = styled.h4`
  text-align: center;
  font-weight: normal;
  padding: 0;
`;

export const MainText = styled.h3`
  text-align: center;
`;

export const SubsidaryText = styled.h5`
  span{
    text-align: center;
  }
  background-color: rgba(0, 0, 0, 0.2);
  padding: 0.5rem;
  border-radius: 2rem;
`;