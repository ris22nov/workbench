import React from "react";
import { useEffect, useState } from "react";
import {Header} from "../Header";
import { MainContentContainer,RowOne,ColumnOne1,ColumnOne2,SectionTwo,ColumnTwo1,ColumnTwo2,InvoiceContainer,TitleText, GridName,CardContainer } from './MainContent.styles'
import { SnapCard } from './card'
import axios from "axios";
import CbsTable from "./CbsTable";
import SvsTable from "./SvsTable";
import ReturnTable from "./ReturnTable";

const gridName = {1760:'CHENNAI',1745:'DELHI',136:'MUMBAI',469:'BENGALURU'};
/*const gridName = {1760:'CHENNAI'};*/
const grid = [1760,1745,136,469];
/*const grid = [1760];*/
const backgroundcolors = {136:'#5F8575', 1745:'#E1C16E', 1760:'#E3735E',469:'#7393B3'};
const staturl = 'http://10.255.18.87:5000/status/';
let count = 0;
let gridDp = 1760;


export const MainContent = () => {
    const [stat,setStat] = useState(null);
    /*const [gridId,setGrid] = useState(null);*/
    

    useEffect( () => {
        const interval = setInterval(() => {
            getGrid();
            getStatus();
        },15000);
    return () => clearInterval(interval);
     }, []);

    const getGrid = () => {
        let gridId = grid[count];
        gridDp = gridId;
        count++;
        if (count === grid.length){
            count = 0
        }
    }

    const getStatus = () => {
        axios.get(staturl+gridDp).then((response) => {
            setStat(response.data)
        })
        .catch(error => console.error(`Error: ${error}`));
    }
    if (!stat) return null;

    
    let Total_Instrument = (!("Total_Instrument" in stat)) ? 0 : stat.Total_Instrument; 
    let Total_Instrument_Value = (!("Total_Instrument_Value" in stat)) ? 0.00 : stat.Total_Instrument_Value;
    let Total_Cheque = (!("Total_Cheque" in stat)) ? 0 : stat.Total_Cheque; 
    let Total_Cheque_Amount = (!("Total_Cheque_Amount" in stat)) ? 0.00 : stat.Total_Cheque_Amount; 
    let Total_DDs = (!("Total_DDs" in stat)) ? 0 : stat.Total_DDs;  
    let Total_DDs_Amount = (!("Total_DDs_Amount" in stat)) ? 0.00 : stat.Total_DDs_Amount;
    let Instrument_Passed_in_SVS = (!("Instrument_Passed_in_SVS" in stat)) ? 0.00 : stat.Instrument_Passed_in_SVS;
    let Instrument_Passed_in_SVS_Amount = (!("Instrument_Passed_in_SVS_Amount" in stat)) ? 0.00 : stat.Instrument_Passed_in_SVS_Amount;
    let Instrument_Rejected_in_SVS = (!("Instrument_Rejected_in_SVS" in stat)) ? 0.00 : stat.Instrument_Rejected_in_SVS; 
    let Instrument_Rejected_in_SVS_Amount = (!("Instrument_Rejected_in_SVS_Amount" in stat)) ? 0.00 : stat.Instrument_Rejected_in_SVS_Amount;
    let Instrument_Pending_in_SVS = (!("Instrument_Pending_in_SVS" in stat)) ? 0 : stat.Instrument_Pending_in_SVS; 
    let Instrument_Pending_in_SVS_Amount = (!("Instrument_Pending_in_SVS_Amount" in stat)) ? 0.00 : stat.Instrument_Pending_in_SVS_Amount;   
    let Instrument_Passed_in_CBS = (!("Instrument_Passed_in_CBS" in stat)) ? 0 : stat.Instrument_Passed_in_CBS; 
    let Instrument_Passed_in_CBS_Amount = (!("Instrument_Passed_in_CBS_Amount" in stat)) ? 0.00 : stat.Instrument_Passed_in_CBS_Amount; 
    let Instrument_Rejected_in_CBS = (!("Instrument_Rejected_in_CBS" in stat)) ? 0 : stat.Instrument_Rejected_in_CBS;  
    let Instrument_Rejected_in_CBS_Amount = (!("Instrument_Rejected_in_CBS_Amount" in stat)) ? 0.00 : stat.Instrument_Rejected_in_CBS_Amount;
    let Instrument_Pending = (!("Instrument_Pending" in stat)) ? 0 : stat.Instrument_Pending; 
    let Instrument_Pending_Amount = (!("Instrument_Pending_Amount" in stat)) ? 0.00 : stat.Instrument_Pending_Amount;
    let Return_Uploaded = (!("Return_Uploaded" in stat)) ? 0.00 : stat.Return_Uploaded;
    let Return_Uploaded_Amount = (!("Return_Uploaded_Amount" in stat)) ? 0.00 : stat.Return_Uploaded_Amount;
    let Instrument_Returned = (!("Instrument_Returned" in stat)) ? 0 : stat.Instrument_Returned; 
    let Instrument_Returned_Amount = (!("Instrument_Returned_Amount" in stat)) ? 0.00 : stat.Instrument_Returned_Amount; 
    let DD_Liquidated = (!("DD_Liquidated" in stat)) ? 0 : stat.DD_Liquidated;
    let DD_Liquidated_Amount = (!("DD_Liquidated_Amount" in stat)) ? 0.00 : stat.DD_Liquidated_Amount;
    let glm_processed = (!("GLM_Processed" in stat)) ? 0 : stat.GLM_Processed;
    let glm_processed_Amount = (!("GLM_Processed_Amount" in stat)) ? 0.00 : stat.GLM_Processed_Amount;
    let OLTC_Processed = (!("OLTC_Processed" in stat)) ? 0 : stat.OLTC_Processed;
    let OLTC_Processed_Amount = (!("OLTC_Processed_Amount" in stat)) ? 0.00 : stat.OLTC_Processed_Amount;


    return (
        <MainContentContainer>
            <RowOne>
                <GridName>{gridName[gridDp]}</GridName>
                <CardContainer>
                    <ColumnOne1>
                        <SnapCard inputColor = {backgroundcolors[gridDp]} key = 'inward' heading = 'INWARD' 
                                  mainText={Total_Instrument+' - '+ (Total_Instrument_Value/10000000).toLocaleString('en-IN', {maximumFractionDigits: 2,style: 'currency',currency: 'INR'}) +' Cr' } 
                                  subsidaryText = {['CHEQUE '+Total_Cheque+' - '+ (Total_Cheque_Amount/10000000).toLocaleString('en-IN', {maximumFractionDigits: 2,style: 'currency',currency: 'INR'}) +' Cr',
                                  'DDs    '+ Total_DDs+' - '+ (Total_DDs_Amount/10000000).toLocaleString('en-IN', {maximumFractionDigits: 2,style: 'currency',currency: 'INR'}) +' Cr' ]}/>
                    </ColumnOne1>
                    <ColumnOne1>
                        <SnapCard inputColor = {backgroundcolors[gridDp]} key = 'svs' heading = 'SVS' 
                                  mainText={Instrument_Passed_in_SVS+' - '+ (Instrument_Passed_in_SVS_Amount/10000000).toLocaleString('en-IN', {maximumFractionDigits: 2,style: 'currency',currency: 'INR'}) +' Cr' } 
                                  subsidaryText = {['REJECTED '+Instrument_Rejected_in_SVS+' - '+ (Instrument_Rejected_in_SVS_Amount/10000000).toLocaleString('en-IN', {maximumFractionDigits: 2,style: 'currency',currency: 'INR'}) +' Cr',
                                  'PENDING '+ Instrument_Pending_in_SVS+' - '+ (Instrument_Pending_in_SVS_Amount/10000000).toLocaleString('en-IN', {maximumFractionDigits: 2,style: 'currency',currency: 'INR'}) +' Cr' ]}/>
                    </ColumnOne1>
                    <ColumnOne1>
                        <SnapCard inputColor = {backgroundcolors[gridDp]} key = 'cbs' heading = 'CBS' 
                                  mainText={Instrument_Passed_in_CBS+' - '+ (Instrument_Passed_in_CBS_Amount/10000000).toLocaleString('en-IN', {maximumFractionDigits: 2,style: 'currency',currency: 'INR'}) +' Cr' } 
                                  subsidaryText = {['REJECTED '+Instrument_Rejected_in_CBS+' - '+ (Instrument_Rejected_in_CBS_Amount/10000000).toLocaleString('en-IN', {maximumFractionDigits: 2,style: 'currency',currency: 'INR'}) +' Cr']}/>
                    </ColumnOne1>
                    <ColumnOne1>
                        <SnapCard inputColor = {backgroundcolors[gridDp]} key = 'dd' heading = 'DD / GLM' 
                                  mainText={(DD_Liquidated+glm_processed+OLTC_Processed)+' - '+ ((DD_Liquidated_Amount+glm_processed_Amount+OLTC_Processed_Amount)/10000000).toLocaleString('en-IN', {maximumFractionDigits: 2,style: 'currency',currency: 'INR'}) +' Cr' } 
                                  subsidaryText = {['DD '+DD_Liquidated+' - '+ (DD_Liquidated_Amount/10000000).toLocaleString('en-IN', {maximumFractionDigits: 2,style: 'currency',currency: 'INR'}) +' Cr',
                                  'GLM  '+ (glm_processed+OLTC_Processed)+' - '+ ((glm_processed_Amount+OLTC_Processed_Amount)/10000000).toLocaleString('en-IN', {maximumFractionDigits: 2,style: 'currency',currency: 'INR'}) +' Cr' ]}/>
                    </ColumnOne1>
                    <ColumnOne1>
                        <SnapCard inputColor = {backgroundcolors[gridDp]} key = 'returned' heading = 'RETURNED' 
                                  mainText={Instrument_Returned+' - '+ (Instrument_Returned_Amount/10000000).toLocaleString('en-IN', {maximumFractionDigits: 2,style: 'currency',currency: 'INR'}) +' Cr' } 
                                  subsidaryText = {['UPLOADED '+Return_Uploaded+' - '+ (Return_Uploaded_Amount/10000000).toLocaleString('en-IN', {maximumFractionDigits: 2,style: 'currency',currency: 'INR'}) +' Cr']}/>
                    </ColumnOne1>
                    <ColumnOne1>
                        <SnapCard inputColor = {backgroundcolors[gridDp]} key = 'unprocess' heading = 'UNTALLIED' 
                                  mainText={Instrument_Pending+' - '+ (Instrument_Pending_Amount/10000000).toLocaleString('en-IN', {maximumFractionDigits: 2,style: 'currency',currency: 'INR'}) +' Cr' } 
                                  subsidaryText = {[]}/>
                    </ColumnOne1>
                </CardContainer>
            </RowOne>
            <SectionTwo>
                <ColumnTwo2>
                    <TitleText>SVS</TitleText>
                    <SvsTable />
                </ColumnTwo2>
                <ColumnTwo2>
                    <TitleText>CBS</TitleText>
                    <CbsTable />
                </ColumnTwo2>
                <ColumnTwo2>
                    <TitleText>RETURN</TitleText>
                    <ReturnTable />
                </ColumnTwo2>
            </SectionTwo>
        </MainContentContainer>
    );
};