import styled from 'styled-components';

export const StyledTable = styled.table`
  	border-spacing: 0px;
    width:500px;
	box-shadow: 5px 4px 30px rgba(0,0,0,.10);
	border-radius: 10px;
	background: #fff;
	transition: all .5s;
`;

export const THead = styled.thead`
    background: linear-gradient(45deg, #614ad3, #e42c64);
    align-items: center;
`;

export const TFoot = styled.tfoot`
    
`;

export const TBody = styled.tbody`
 
`;

export const TR = styled.tr`
`;

export const TH = styled.th`
    padding: 25px;
    color: #fff;
    font-size: 15px;
`;

export const TD = styled.td`
    padding: 20px;
    text-align: center;
    td:first-of-type{
        text-align: left;
    }
`;