import React from "react";
import { useEffect, useState } from "react";
import axios from "axios";
import Table from "./table";
const cbsstaturl = 'http://10.255.18.87:5000/cbsstatus'

function CbsTable(props) {
    const [cbsStat,setCbsStat] = useState(null);
    useEffect( () => {
        const interval = setInterval(() => {
            getCbsStatus();
        },15000);
    return () => clearInterval(interval);
     }, []);

    const getCbsStatus = () => {
        axios.get(cbsstaturl).then((response) => {
            setCbsStat(response.data)
        })
        .catch(error => console.error(`Error: ${error}`));
    }
    if (!cbsStat) return null;

    console.log(cbsStat)

    return (
        <Table
            headingColumns={['GRID','PASSED', 'REJECTED', 'PENDING', 'TIME']}
            tableData={cbsStat}
        />
    )
}

export default CbsTable