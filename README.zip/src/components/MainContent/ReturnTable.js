import React from "react";
import Table from "./table";

function CbsTable(props) {
    return (
        <Table 
            headingColumns={['GRID', 'MARKED', 'UPLOADED', 'RETURNED', 'PENDING']}
        />
    )
}

export default CbsTable