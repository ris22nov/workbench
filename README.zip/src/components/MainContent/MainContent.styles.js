import styled from 'styled-components';



export const MainContentContainer = styled.div`
  margin-right:1rem;
  margin-left:1rem;
  height: 100%;
  width: 100%;
  display: flex;
  flex-direction: column;
  @media screen and (min-width: 320px) and (max-width: 1080px) {
    height: 100%;
  }
`;
export const RowOne = styled.div`
  display: flex;
  height: 40%;
  width: 15%;
  flex-direction: column;
  @media screen and (min-width: 320px) and (max-width: 1080px) {
    flex-direction: column;
    align-items: center;
    height: max-content;
  }
`;
export const ColumnOne1 = styled.div`
  display: flex;
  gap: 3rem;
  @media screen and (min-width: 320px) and (max-width: 1080px) {
    flex-direction: column;
    justify-content: center;
    align-items: center;
    gap: 1rem;
    width: 100%;
  }
`;

export const CardContainer = styled.div
`
    display: flex;
    gap: 1rem;
    flex-direction: row;
`

export const ColumnTwo1 = styled.div`
  display: flex;
  flex-direction: column;
  height: 115%;
  width: 100%;
  @media screen and (min-width: 320px) and (max-width: 1080px) {
    height: max-content;
    justify-content: center;
    align-items: center;
  }
`;

export const GridName = styled.h2`
`;

export const TitleText = styled.h3`
  padding-top: 50px;
  padding-bottom: 5px;
  text-align: center;
`;

export const SectionTwo = styled.div`
  display: flex;
  gap: 2rem;
  height: 26vh;
  @media screen and (min-width: 320px) and (max-width: 1080px) {
    flex-direction: column;
    height: max-content;
    width: 100%;
  }
`;
export const ColumnOne2 = styled.div`
  @media screen and (min-width: 320px) and (max-width: 1080px) {
    display: flex;
    border: 1px solid;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    width: 100%;
  }
`;
export const InvoiceContainer = styled.div`
  height: 60%;
  @media screen and (min-width: 320px) and (max-width: 1080px) {
    height: max-content;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    width: 100%;
  }
`;

export const ColumnTwo2 = styled.div`
  @media screen and (min-width: 320px) and (max-width: 1080px) {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
  }
`;