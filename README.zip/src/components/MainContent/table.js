import React from "react";
import { StyledTable,THead,TBody,TFoot,TH,TR,TD } from "./table.style";

function Table(props) {
    let data = null;
    if (props.tableData){
        data = props.tableData.map((row, index) => {
            let rowData = [];
            let i = 0;
            for(const key in row) {
                rowData.push({
                    key: props.headingColumns[i],
                    val: row[key]
                });
                i++;
            }
        
            return <TR key={index}>{rowData.map((data, index) => <TD key={index} data-heading={data.key}>{data.val}</TD>)}</TR>
        });}
    else {
        data = null;
    }   
    return (
        
        <StyledTable>
            <THead>
            <TR>
                {props.headingColumns.map((col, index) => (
                <TH key={index}>{col}</TH>
                ))}
            </TR>
            </THead>
            <TBody>
                {data}
            </TBody>
  </StyledTable>
    )
}

export default Table


