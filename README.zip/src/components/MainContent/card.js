import React from "react";
import { Card,CardContent,HeadingText,MainText,SubsidaryText} from "./card.styles";

export const SnapCard = (props) => {
  
  let subsidary = [];
  props.subsidaryText.forEach((item,index) => {
    subsidary.push(<SubsidaryText>{item}</SubsidaryText>)
  });

  return (
    <Card inputColor = {props.inputColor}>
      <CardContent>
        <HeadingText>{props.heading}</HeadingText>
        <MainText>{props.mainText}</MainText>
        {subsidary}
      </CardContent>
    </Card>
  );
};