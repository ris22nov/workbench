import React from "react";
import Table from "./table";

function CbsTable(props) {
    return (
        <Table 
            headingColumns={['GRID', 'PASSED', 'REJECTED', 'SKIPPED', 'PENDING']}
        />
    )
}

export default CbsTable