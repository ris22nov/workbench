import React from "react";
import { FiSearch } from "react-icons/fi";
import { FooterContainer,HeaderLeft,HeaderRight,SearchIcon,SearchBox, Logo } from './Header.styles'
import CanaraLogo from '../../assets/images/logo.png'

export const Footer = () => {
  return (
    <FooterContainer>
    </FooterContainer>
  );
};
