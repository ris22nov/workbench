import styled from 'styled-components';

export const FooterContainer = styled.nav`
  display: flex;
  justify-content: space-between;
  align-items: center;
  height: 8%;
  width: 100%;
  background-color:#474747;
  border-radius: 0 0 1rem 1rem ;
  @media screen and (min-width: 320px) and (max-width: 1080px) {
    flex-direction: column;
    margin-bottom: 1rem;
  }
`;

export const HeaderLeft = styled.div`
  h1 {
    font-weight: 500;
    color: #e6e4ff;
    margin: 1rem
  }
  @media screen and (min-width: 320px) and (max-width: 1080px) {
    margin-top: 1rem;
  }
`;

export const HeaderRight = styled.div`
  display: flex;
  margin: 1rem;
`;

export const SearchIcon = styled.div`
  height: 3rem;
  width: 3rem;
  background-color: #dce4ff;
  display: flex;
  justify-content: center;
  align-items: center;
  border-top-left-radius: 0.5rem;
  border-bottom-left-radius: 0.5rem;
  svg {
    color: #555555;
  }
`;
export const SearchBox = styled.input`
  border: none;
  background-color: #dce4ff;
  border-top-right-radius: 0.5rem;
  border-bottom-right-radius: 0.5rem;
  color: #464646;
  margin-right: 1rem;
  &:focus {
    border: none;
    outline: none;
  }
`;

export const Logo = styled.img
`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  cursor: pointer;
`;