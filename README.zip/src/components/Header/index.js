import React from "react";
import { FiSearch } from "react-icons/fi";
import { HeaderContainer,HeaderLeft,HeaderRight,SearchIcon,SearchBox, Logo } from './Header.styles'
import CanaraLogo from '../../assets/images/logo.png'

export const Header = () => {
  return (
    <HeaderContainer>
      <HeaderLeft>
        <h1>D A S H B O A R D</h1>
      </HeaderLeft>
      <HeaderRight>
        <SearchIcon>
          <FiSearch />
        </SearchIcon>
        <SearchBox type="text" placeholder="Search for Cheques" />
        <Logo src={CanaraLogo} alt='HO'/>
      </HeaderRight>
    </HeaderContainer>
  );
};
