import { createGlobalStyle } from 'styled-components';

export const GlobalStyle = createGlobalStyle`
    @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap");
    :root {
        --header-height: 3rem;
        --nav-width: 68px;
        --white-color: #F7F6FB;
        --dark-color:#2b2b2d;
        --off-white-color:#bdbfbf;
        --body-font: 'Poppins', sans-serif;
        --normal-font-size: 1rem;
        --z-fixed: 100;
        
    }
    *,
    ::before,
    ::after {
        box-sizing: border-box
    }
    body {
        position: relative;
        margin: 1rem;
        padding: 0;
        background-color: var(--white-color);
        font-family: var(--body-font);
        font-size: var(--normal-font-size);
        transition: 0.5s;
    }
    a {
        text-decoration: none
    }
`;
