import axios from "axios";

async function getStatus() {
    const response = await axios.get('http://127.0.0.1:5000/status/1760')
    return response.data
}

export default getStatus


